<?php



use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if(!defined('ABSPATH')) exit;


class CountdownTimer extends Widget_Base{

	public function get_name(){
		return "countdown-timer";
	}
	
	public function get_title(){
		return "Countdown Timer";
	}
	
	public function get_icon(){
		return "eicon-countdown";
	}
	
	public function get_categories(){
		return ['dreamit-category'];
	}

	protected function register_controls(){

		$this->start_controls_section(
			'timer_section',
			[
				'label' => esc_html__( 'Timer', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'due_date',
			[
				'label' => esc_html__( 'Date', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::DATE_TIME,
			]
		);

		$this->end_controls_section();

/*
==========
Style Tab
==========
*/

		$this->start_controls_section(
			'general_section',
			[
				'label' => __( 'General', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'select_style',
				[
					'label' => __( 'Select Style', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'dreamit-elementor-extension' ),
						'two' => __( 'Two', 'dreamit-elementor-extension' ),
					],
					'default' => 'one',
					
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'date_style',
			[
				'label' => esc_html__( 'Date', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'date_color',
			[
				'label' => esc_html__( 'Color', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .countdown-timer #date li h3' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'date_typography',
				'selector' => '{{WRAPPER}} .countdown-timer #date li h3',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'date_background',
				'label' => esc_html__( 'Background', 'dreamit-elementor-extension' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .countdown-timer #date li h3',
			]
		);
		$this->add_control(
			'margin',
			[
				'label' => esc_html__( 'Margin', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .countdown-timer #date li h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Color', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .countdown-timer #date li span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'selector' => '{{WRAPPER}} .countdown-timer #date li span',
			]
		);
		$this->add_control(
			'text_margin',
			[
				'label' => esc_html__( 'Margin', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .countdown-timer #date li span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

	}

	protected function render(){

		$settings = $this->get_settings_for_display();
		
		?>

			<?php if($settings['select_style']=='one'){ ?>

				<div class="countdown-timer style1">
					<ul id="date"></ul>
				</div>

				<script>

					// Set the date we're counting down to
					var countDownDate = new Date("<?php echo $settings['due_date']; ?>").getTime();

					// Update the count down every 1 second
					var x = setInterval(function() {

						// Get today's date and time
						var now = new Date().getTime();

						// Find the distance between now and the count down date
						var distance = countDownDate - now;

						// Time calculations for days, hours, minutes and seconds
						var days = Math.floor(distance / (1000 * 60 * 60 * 24));
						var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
						var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
						var seconds = Math.floor((distance % (1000 * 60)) / 1000);

						document.getElementById("date").innerHTML = 

							`<li class="days">
								<h3 class="day">${days}</h3>
								<span>Days</span>
							</li>
							<li class="hours">
								<h3 class="hour">${hours}</h3>
								<span>Hours</span>
							</li>
							<li class="minutes">
								<h3 class="minute">${minutes}</h3>
								<span>Minutes</span>
							</li>
							<li class="seconds">
								<h3 class="second">${seconds}</h3>
								<span>Seconds</span>
							</li>`;

						if (distance < 0) {
							clearInterval(x);
							document.getElementById("date").innerHTML = "EXPIRED";
						}
					}, 1000);

				</script>

			<?php }elseif($settings['select_style']=='two'){ ?>

				<div class="countdown-timer style2">
					<ul id="date"></ul>
				</div>

				<script>

					// Set the date we're counting down to
					var countDownDate = new Date("<?php echo $settings['due_date']; ?>").getTime();

					// Update the count down every 1 second
					var x = setInterval(function() {

						// Get today's date and time
						var now = new Date().getTime();

						// Find the distance between now and the count down date
						var distance = countDownDate - now;

						// Time calculations for days, hours, minutes and seconds
						var days = Math.floor(distance / (1000 * 60 * 60 * 24));
						var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
						var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
						var seconds = Math.floor((distance % (1000 * 60)) / 1000);

						document.getElementById("date").innerHTML = 

							`<li class="days">
								<h3 class="day">${days}</h3>
								<span>Days</span>
							</li>
							<li class="hours">
								<h3 class="hour">${hours}</h3>
								<span>Hours</span>
							</li>
							<li class="minutes">
								<h3 class="minute">${minutes}</h3>
								<span>Minutes</span>
							</li>
							<li class="seconds">
								<h3 class="second">${seconds}</h3>
								<span>Seconds</span>
							</li>`;

						if (distance < 0) {
							clearInterval(x);
							document.getElementById("date").innerHTML = "EXPIRED";
						}
					}, 1000);

				</script>

			<?php } ?>

		<?php
	}
	
}